#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. ./so_utils.sh                     ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024, Enunciado Versão 3+
##
## Aluno: Nº: 122627      Nome: Gonçalo Guilherme
## Nome do Módulo: S1. Script: regista_passageiro.sh
## Descrição/Explicação do Módulo:
## Neste módulo um passageiro será registado num ficheiro passageiros.txt a partir de algumas informações como: NIF; palavra-passe; id do Tigre; etc...
## São validados os 4 ou 3 argumentos passados pelo user, escreve-se as informações do passageiro em passageiros.txt, adiciona-se saldos e têm-se acesso a um ficheiro com os passageiros registados ordenados pelo seu saldo (passageiros-saldos-ordenados.txt)
###############################################################################

## Este script é invocado quando um novo passageiro se regista na plataforma IscteFlight. Este script recebe todos os dados por argumento, na chamada da linha de comandos. Os passageiros são registados no ficheiro passageiros.txt. Deve receber as informações do passageiro como argumentos pela seguinte ordem: <Nome:string> <Senha:string>  <Saldo a adicionar:number> [<NIF:number>]

## S1.1. Valida os argumentos passados e os seus formatos:
## S1.1.1. Valida os argumentos passados, avaliando se são em número suficiente (mínimo 3, máximo 4). Em caso de erro, dá so_error S1.1.1 e termina. Caso contrário, dá so_success S1.1.1.

if [ "$#" -lt 3 ] || [ "$#" -gt 4 ]; then ## Verifica se o número de argumentos passados é válido
    so_error S1.1.1 
    exit 9
else
    so_success S1.1.1
fi

## S1.1.2. Valida se o argumento <Nome> corresponde ao nome de um utilizador do servidor Tigre. Se não corresponder ao nome de nenhum utilizador do Tigre, dá so_error S1.1.2 e termina. Senão, dá so_success S1.1.2.

if grep -q ":$1," "_etc_passwd"; then ## Verifica se o nome passado existe no servidor tigre
    so_success S1.1.2
else
    so_error S1.1.2 
    exit 9
fi

## S1.1.3. Valida se o argumento <Saldo a adicionar> tem formato “number” (inteiro positivo ou 0). Se não tiver, dá so_error S1.1.3 e termina. Caso contrário, dá so_success S1.1.3.

if [[ $3 =~ ^[0-9]+$ ]]; then ## Verifica se o saldo é um número inteiro positivo ou 0
    so_success S1.1.3
else
    so_error S1.1.3
    exit 9
fi

## S1.1.4. Valida se o argumento opcional <NIF> (só no caso de ser passado, i.e., se tiver valor) tem formato “number” com 9 (nove) dígitos. Se não for, dá so_error S1.1.4 e termina. Caso contrário, dá so_success S1.1.4.

if [ -n "$4" ]; then ## Verifica se o NIF foi passado como argumento
    if [[ $4 =~ ^[0-9]{9}$ ]]; then ## Verifica se o NIF, caso tenha sido passado, está no formato certo
        so_success S1.1.4
    else
        so_error S1.1.4
        exit 9
    fi
fi

## S1.2. Associa os dados passados com a base de dados dos passageiros registados:
## S1.2.1. Verifica se o ficheiro passageiros.txt existe. Se o ficheiro existir, dá so_success S1.2.1 e continua no passo S1.2.3. Se não existir, dá so_error S1.2.1, e continua.
## S1.2.2. Cria o ficheiro passageiros.txt. Se der erro, dá so_error S1.2.2 e termina. Senão, dá so_success S1.2.2.

if [ -f "passageiros.txt" ]; then ## Verifica se passageiros.txt existe, senão cria-o
    so_success S1.2.1
else
    so_error S1.2.1
    touch passageiros.txt
    if [ -f "passageiros.txt" ]; then ## Verifica novamente se passsageiros.txt existe
        so_success S1.2.2
    else
        so_error S1.2.2
        exit 9
    fi
fi

## S1.2.3. Caso o passageiro <Nome> passado já exista no ficheiro passageiros.txt, dá so_success S1.2.3, e continua no passo S1.3.  Senão, dá so_error S1.2.3, e continua.
## S1.2.4. Como o passageiro <Nome> não existe no ficheiro, terá de o registar. Para isso, valida se <NIF> (campo opcional) foi mesmo passado. Se não foi, dá so_error S1.2.4 e termina. Senão, dá so_success S1.2.4.
## S1.2.5. Define o campo <ID_passageiro>, como sendo o UserId Linux associado ao utilizador de nome <Nome> no servidor Tigre. Em caso de haver algum erro na operação, dá so_error S1.2.5 e termina. Caso contrário, dá so_success S1.2.5 <ID_passageiro> (substituindo pelo campo definido).
## S1.2.6. Define o campo <Email>, gerado a partir do <Nome> introduzido pelo utilizador, usando apenas o primeiro e o último nome (dica: https://moodle23.iscte-iul.pt/mod/forum/discuss.php?d=5344), convertendo-os para minúsculas apenas, colocando um ponto entre os dois nomes, e domínio iscteflight.pt. Assim sendo, um exemplo seria “david.gabriel@iscteflight.pt”. Se houver algum erro na operação (e.g., o utilizador “root” tem menos de 2 nomes), dá so_error S1.2.6 e termina. Caso contrário, dá so_success S1.2.6 <Email> (substituindo pelo campo gerado). Ao registar um novo passageiro no sistema, o número inicial de <Saldo> tem o valor 0 (zero).
## S1.2.7. Regista o utilizador numa nova linha no final do ficheiro passageiros.txt, seguindo a sintaxe:   <ID_passageiro>:<NIF>:<Nome>:<Email>:<Senha>:<Saldo>. Em caso de haver algum erro na operação (e.g., erro na escrita do ficheiro), dá so_error S1.2.7 e termina. Caso contrário, dá so_success S1.2.7 <linha> (substituindo pela linha completa escrita no ficheiro).

if grep -q "$1" passageiros.txt; then ## Verifica se o nome passado está registado em passageiros.txt
    so_success S1.2.3
    senha_registada=$( grep "$1" passageiros.txt | cut -d ':' -f 5 ) ## Pega a senha registada em passageiros.txt associada ao passageiro pretendido
else
    so_error S1.2.3
    if [ -n "$4" ]; then ## Verifica se o argumento 4 (NIF) foi passado
        so_success S1.2.4
        ID_passageiro=$( grep "$1" _etc_passwd | cut -d ':' -f 1 ) ## Pega o id do tigre associado ao passageiro pretendido
        if [ $? -eq 0 ]; then ## Verifica se a operação correu bem
            so_success S1.2.5 "$ID_passageiro" 
            primeiro_nome=$( echo "$1" | cut -d ' ' -f 1 | tr '[:upper:]' '[:lower:]' ) ## Saca o primeiro nome do passageiro e coloca-o em minúsculas
            ultimo_nome=$( echo "$1" | awk '{print $NF}' | tr '[:upper:]' '[:lower:]' ) ## Saca o último nome do passageiro e coloca-o em minúsculas
            if [ -z "$primeiro_nome" ] || [ -z "$ultimo_nome" ]; then ## Verifica se os nomes sacados estão "vazios"
                so_error S1.2.6
                exit 9
            fi
            Email="$primeiro_nome.$ultimo_nome@iscteflight.pt" ## Cria um e-mail para o passsageiro pretendido
            so_success S1.2.6 "$Email"
            linha="$ID_passageiro:$4:$1:$Email:$2:$3" ## Transforma as informações numa "linha"
            echo $linha >> passageiros.txt ## Escreve a "linha" no fim de passageiros.txt
            if [ $? -eq 0 ]; then ## Verifica se a operação correu bem
                so_success S1.2.7 "$linha"
            else
                so_error S1.2.7 
                exit 9 
            fi
        else
            so_error S1.2.5
            exit 9
        fi
    else
        so_error S1.2.4
        exit 9
    fi 
    exit 9
fi
    
## S1.3. Adiciona créditos na conta de um passageiro que existe no ficheiro passageiros.txt:
## S1.3.1. Tendo já encontrado um “match” passageiro com o Nome <Nome> no ficheiro, valida se o campo <Senha> passado corresponde à senha registada no ficheiro. Se não corresponder, dá so_error S1.3.1 e termina. Caso contrário, dá so_success S1.3.1.

if [ "$senha_registada" != "$2" ]; then ## Verifica se a senha registada e a senha passada associadas ao passageiro pretendido são correspondentes
    so_error S1.3.1
    exit 9
else
    so_success S1.3.1
fi

## S1.3.2. Mesmo que tenha sido passado um campo <NIF> (opcional), ignora-o. Adiciona o valor passado do campo <Saldo a adicionar> ao valor do <Saldo> registado no ficheiro passageiros.txt para o passageiro em questão, atualizando esse valor no ficheiro passageiros.txt. Se houver algum erro na operação (e.g., erro na escrita do ficheiro), dá so_error S1.3.2 e termina. Caso tudo tenha corrido bem, dá o resultado so_success S1.3.2 <Saldo> (substituindo pelo valor saldo atualizado no ficheiro passageiros.txt).

saldo=$( grep "$1" passageiros.txt | cut -d ':' -f 6 ) ## Pega o saldo do passageiro pretendido
novo_saldo=$(($saldo + $3)) ## Calcula o novo saldo do passaageiro em questão
sed -i "/^[^:]*:[^:]*:$1:[^:]*:[^:]*:$saldo/s/$saldo/$novo_saldo/" passageiros.txt ## Atualiza o saldo do passageiro em questão
if [ $? -eq 0 ]; then ## Verifica se a operação correu bem
    so_success S1.3.2 "$novo_saldo"
else
    so_error S1.3.2
    exit 9
fi

## S1.4. Lista todos os passageiros registados, mas ordenados por saldo:
## S1.4.1. O script deve criar um ficheiro chamado passageiros-saldos-ordenados.txt igual ao que está no ficheiro passageiros.txt, com a mesma formatação, mas com os registos ordenados por ordem decrescente do campo <Saldo> dos passageiros. Se houver algum erro (e.g., erro na leitura ou escrita do ficheiro), dá so_error S1.4.1, e termina. Caso contrário, dá so_success S1.4.1.

touch passageiros-saldos-ordenados.txt ## Cria o passageiros-saldos-ordenados.txt
sort -t ':' -k 6,6nr passageiros.txt > passageiros-saldos-ordenados.txt ## Ordena os saldos dos passageiros em passageiros.txt e escreve em passageiros-saldos-ordenados.txt
if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
    so_success S1.4.1
else
    so_error S1.4.1
    exit 9
fi