#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. ./so_utils.sh                     ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024, Enunciado Versão 3+
##
## Aluno: Nº:  122627     Nome: Gonçalo Guilherme
## Nome do Módulo: S4. Script: stats.sh
## Descrição/Explicação do Módulo:
## Neste módulo os argumento começam por ser avaliados, consoante os argumentos passados, a operação a realizar será a de "top <numero>" ou "passageiros" onde se escreve em stats.txt os passageiros com mais reservas ("passageiros") ou o ranking de voos mais rentáveis ("top <numero>")
##
###############################################################################

## Este script obtém informações sobre o sistema, afixando resultados diferentes no STDOUT consoante os argumentos passados na sua invocação. A sintaxe resumida é: ./stats.sh <passageiros>|<top <nr>>

## S4.1. Validações:
## S4.1.1. Valida os argumentos recebidos e, conforme os mesmos, o número e tipo de argumentos recebidos. Se não respeitarem a especificação, dá so_error e termina. Caso contrário, dá so_success.

if [ "$#" -lt 1 ] || [ "$#" -gt 2 ]; then ## Verfica se o número de argumentos está entre 1 e 2
    so_error S4.1.1
    exit 9
fi
if [ "$#" -eq 1 ]; then ## No caso de só haver um argumento passado, este tem de ser "passageiros"
    if [ "$1" != "passageiros" ]; then ## Verfica se o argumento passado é "passageiros"
        so_error S4.1.1
        exit 9
    else
        so_success S4.1.1
    fi
else
    if [ "$1" = "top" ] && [[ "$2" =~ ^[0-9]+$ ]];then ## Caso haja dois argumentos passados, o primeiro tem de ser "top" e o segundo um número válido 
        so_success S4.1.1
    else
        so_error S4.1.1
        exit 9
    fi
fi


## S4.2. Invocação do script:
## S4.2.1. Se receber o argumento passageiros, (i.e., ./stats.sh passageiros) cria um ficheiro stats.txt onde lista o nome de todos os utilizadores que fizeram reservas, por ordem decrescente de número de reservas efetuadas, e mostrando o seu valor total de compras. Em caso de erro (por exemplo, se não conseguir ler algum ficheiro necessário), dá so_error e termina. Caso contrário, dá so_success e cria o ficheiro. Em caso de empate no número de reservas, lista o primeiro do ficheiro. Preste atenção ao tratamento do singular e plural quando se escreve “reserva” no ficheiro).

rm -f stats.txt ## Remove stats.txt caso haja (para criar um novo)
if [ "$1" == "passageiros" ]; then
    touch stats.txt ## Cria um stats.txt novo 
    awk -F: '{passengers[$6]++; prices[$6]+=$5} END {for (passenger in passengers) print passengers[passenger], prices[passenger], passenger}' relatorio_reservas.txt | sort -rn | while IFS=" " read -r count total passenger; do ## Awk ao relatorio_reservas.txt onde irá buscar o id do passageiro, o numero das suas reservas e o valor total das suas compras, ordenando por ordem decrescente
        nome_passenger=$(grep "$passenger" /etc/passwd | cut -d ':' -f 5 | sed 's/,,,//g') ## Pega o nome do passageiro pelo seu id
        if [[ $count -gt 1 ]]; then
            echo "$nome_passenger: $count reservas; $total€" >> stats.txt ## Quando o número de reservas for maior que 1, usa a palavra "reservas"
        else 
            echo "$nome_passenger: $count reserva; $total€" >> stats.txt ## Quando o número de reservas é 1, usa a palavra "reserva"
        fi
    done
    if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
      so_success S4.2.1
    else
       so_error S4.2.1
       exit 9
    fi
fi

## S4.2.2. Se receber o argumento top <nr:number>, (e.g., ./stats.sh top 4), cria um ficheiro stats.txt onde lista os <nr> (no exemplo, os 4) voos mais rentáveis (que tiveram melhores receitas de vendas), por ordem decrescente. Em caso de erro (por exemplo, se não conseguir ler algum ficheiro necessário), dá so_error e termina. Caso contrário, dá so_success e cria o ficheiro. Em caso de empate, lista o primeiro do ficheiro.

if [[ "$1" = "top" ]] && [[ "$2" =~ ^[1-9][0-9]*$ ]]; then
    numero=$2 ## Atribui o argumento dois à variável "numero"
    touch stats.txt ## Cria um stats.txt
    sort -t: -k2,2nr -k5,5rn relatorio_reservas.txt | awk -F: '{voo[$2]+=$5} END {for (codigo_voo in voo) print codigo_voo, voo[codigo_voo]}' | sort -t" " -k2,2nr -k1,1 | head -n "$numero" | while read -r codigo_voo total_vendas; do # Organiza os voos em relaroio_reservas.txt por ordem decresecente dos mais rentáveis seguido de um awk ao relatorio_reservas.txt onde irá buscar o código do voo e a soma das suas vendas e escreve no stats.txt consoante o número passado como argumento
        echo "$codigo_voo: $total_vendas€" >> stats.txt 
    done
    if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
        so_success S4.2.2
    else 
        so_error S4.2.2
        exit 9
    fi
fi
