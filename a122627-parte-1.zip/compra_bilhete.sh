#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. ./so_utils.sh                     ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024, Enunciado Versão 3+
##
## Aluno: Nº:  122627     Nome: Gonçalo Teixeira Guilherme 
## Nome do Módulo: S2. Script: compra_bilhete.sh
## Descrição/Explicação do Módulo:
## Neste módulo fazem-se as reservas de voos para os passageiros registados anteriormente e essas reservas são registadas num ficheiro relatorio_reservas.txt junto de algumas informações dos passageiros correspondentes tais como: a data e hora da reserva; id do passageiro no tigre; código do voo; etc...
## Valida se os voos escolhidos estão disponíveis com base nas suas origens/destinos e lugares disponíveis, são confirmadas informações de passageiros faz-se a escrita para o relatorio_reservas.txt 
###############################################################################

## Este script não recebe nenhum argumento, e permite que o passageiro compre um bilhete para um voo da lista de voos disponíveis. Para realizar a compra, o passageiro deve fazer login para confirmar sua identidade e saldo disponível. Os voos disponíveis estão listados no ficheiro voos.txt. Se não quiser produzir o seu próprio ficheiro, pode utilizar o ficheiro exemplo fornecido, dando o comando: cp voos-exemplo.txt voos.txt. O mesmo procedimento pode ser realizado também com o ficheiro passageiros.txt.

## S2.1. Validações e Pedido de informações interativo:
## S2.1.1. O script valida se os ficheiros voos.txt e passageiros.txt existem. Se algum não existir, dá so_error e termina. Caso contrário, dá so_success.

if [ -f "voos.txt" ] && [ -f "passageiros.txt" ]; then ## Verifica se voos.txt e passageiros.txt existem
    so_success S2.1.1
else
    so_error S2.1.1
    exit 9
fi

## S2.1.2. Na plataforma é possível consultar os voos pela sua <Origem> ou <Destino>. Pedindo "Insira a cidade de origem ou destino do voo: _". O utilizador insere a cidade Origem ou Destino do voo (o interesse é que pesquise nos 2 campos). Caso o utilizador tenha introduzido uma cidade que não exista no ficheiro voos.txt, ou se não existirem voos com lugares disponíveis com origem ou destino nessa cidade, dá so_error e termina. Caso contrário, dá so_success <Cidade>.

read -p "Insira a cidade de origem ou destino do voo: " origem_destino ## O user escreve a cidade que pretende
if grep -q "$origem_destino" voos.txt; then ## Verifica se a cidade escolhida existe em voos.txt
    lugares=$( grep "$origem_destino" voos.txt | cut -d ':' -f 8 ) ## Pega os lugares disponíveis para a cidade escolhida no voos.txt
    if [[ $lugares == 0 ]]; then ## Verfica se existem lugares disponíveis para a cidade pretendida 
        so_error S2.1.2
        exit 9
    else
        so_success S2.1.2 "$origem_destino" 
    fi
else
    so_error S2.1.2
    exit 9
fi

## S2.1.3. O programa pede ao utilizador para inserir uma opção de voo, listando os voos que existem de acordo com a origem/destino inserida anteriormente, da seguinte forma: "Lista de voos, numerada, ou 0 para sair, Insira o voo que pretende reservar: _" O utilizador insere a opção do voo (neste exemplo, números de 1 a 3 ou 0). Se o utilizador escolheu um número de entre as opções de voos apresentadas (neste caso, entre 1 e 3), dá so_success <opção>. Caso contrário, dá so_error e termina.

awk -F ':' -v origem="$origem_destino" 'NR==1 { linha=0 } ($2 == origem || $3 == origem) && $8 != 0 { linha++; print linha"."$2" para "$3", "$4", Partida:"$5", Preço: "$6", Disponíveis:"$8" lugares" }' voos.txt
echo "0"".""Sair" ## Awk com condições para recolher todos os voos disponíveis para a cidade escolhida e com lugares disponíveis
opcoes_disponiveis=$(awk -F ':' -v origem_destino="$origem_destino" '$2 == origem_destino || $3 == origem_destino { if ($8 > 0) print $0 }' voos.txt | wc -l) ## Contagem de opções disponíveis para escolha 
read -p "Insira o voo que deseja reservar: " opcao_voo ## O user escreve uma das opções disponíveis 
if [[ $opcao_voo -ge 0 && $opcao_voo -le $opcoes_disponiveis ]]; then ## Verifica se a opção é válida
    if [ $opcao_voo == 0 ];then ## Sai se a opção dada for 0
        exit 9
    fi
    so_success S2.1.3 "Opção: $opcao_voo"
else
    so_error S2.1.3
    exit 9
fi

## S2.1.4. O programa pede ao utilizador o seu <ID_passageiro>: "Insira o ID do seu utilizador: _" O utilizador insere o respetivo ID de passageiro (dica: UserId Linux). Se esse ID não estiver registado no ficheiro passageiros.txt, dá so_error e termina. Caso contrário, reporta so_success <ID_passageiro>.

read -p "Insira o ID do seu utilizador: " id ## O user escreve o id de utilizador do tigre a usar para a reserva
if grep -q "$id" passageiros.txt; then ## Verifica se o id dado está registado em passageiros.txt
    so_success S2.1.4 "$id" 
else
    so_error S2.1.4
    exit 9
fi

## S2.1.5. O programa pede ao utilizador a sua <Senha>: "Insira a senha do seu utilizador: _" O utilizador insere a respetiva senha. Caso o script veja que essa senha não é a registada para esse passageiro no ficheiro passageiros.txt, dá so_error e termina. Caso contrário, reporta so_success.

read -p "Insira a senha do seu utilizador: " senha ## O user escreve a senha referente ao id passado
senha_registada=$( grep "$id" passageiros.txt | cut -d ':' -f 5 ) ## Pega a senha registada em passageiros.txt
if [ "$senha_registada" = "$senha" ]; then ## Verifica se a senha registada em passageiros.txt e a passada pelo user coincidem 
    so_success S2.1.5
else
    so_error S2.1.5
    exit 9
fi

## S2.2. Processamento da resposta:
## S2.2.1. Valida se o passageiro possui <Saldo>, definido no ficheiro passageiros.txt, para comprar o bilhete selecionado no passo S2.1.3. Se a compra não é possível por falta de saldo, dá so_error <preço voo> <Saldo> e termina. Caso contrário, dá so_success <preço voo> <Saldo>.

saldo=$(grep "$id" passageiros.txt | cut -d ':' -f 6) ## Pega o saldo disponível do passageiro em passageiros.txt
preco=$( awk -F ':' -v origem_destino="$origem_destino" '$2 == origem_destino || $3 == origem_destino { if ($8 > 0) print $0 }' voos.txt | grep -n "$origem_destino" | sed -n "${opcao_voo}p" | cut -d ':' -f 7 ) ## Pega o preço do voo escolhido pelo user através de um awk com condições e restringido a opção dada pelo user
if [ "$saldo" -gt "$preco" ]; then ## Verifica se o passageiro encontrado pode fazer a reserva (se o saldo dele é maior que o preço do voo)
    so_success S2.2.1 "$preco" "$saldo" 
else
    so_error S2.2.1 "$preco" "$saldo" 
    exit 9
fi

## S2.2.2. Subtrai o valor do <preço voo> no <Saldo> do passageiro, e atualiza o ficheiro passageiros.txt. Em caso de erro (e.g., na escrita do ficheiro), dá so_error e termina. Senão, dá so_success <Saldo Atual>.

novo_saldo=$(( "$saldo" - "$preco" )) ## Calcula o saldo do passageiro após a reserva
cat passageiros.txt | sed -i "s/$saldo/$novo_saldo/" passageiros.txt ## Atualiza o saldo do passageiro em passageiros.txt
if [ $? -eq 0 ]; then ## Verifica se a operação correu bem
    so_success S2.2.2 "$novo_saldo"
else
    so_error S2.2.2
    exit 9
fi

## S2.2.3. Decrementa uma unidade aos lugares disponíveis do voo escolhidos no passo S2.1.3, e atualiza o ficheiro voos.txt. Em caso de erro (por exemplo, na escrita do ficheiro), dá so_error e termina. Senão, dá so_success.

lugares=$(awk -F ':' -v origem_destino="$origem_destino" '$2 == origem_destino || $3 == origem_destino { if ($8 > 0) print $0 }' voos.txt | grep -n "$origem_destino" | sed -n "${opcao_voo}p" | cut -d ':' -f 9) ## Pega os lugares disponíveis do voo escolhido pelo user (idêntico ao do passo anterior)
lugares_atuais=$((lugares - 1)) ## Decrementa uma unidade aos lugares disponíveis para o voo escolhido
id_voo=$(awk -F ':' -v origem_destino="$origem_destino" '$2 == origem_destino || $3 == origem_destino { if ($8 > 0) print $0 }' voos.txt | grep -n "$origem_destino" | sed -n "${opcao_voo}p" | cut -d ':' -f 2) ## Pega o id do voo escolhido pelo user (idêntico ao anterior)
linha=$( grep -n "$id_voo" voos.txt | cut -d ':' -f 1 ) ## Pega o número da linha correspondente ao voo escolhido pelo user
sed -i "${linha}s/$lugares/$lugares_atuais/" voos.txt ## Troca o número de lugares antigo pelo novo do voo escolhido pelo user 
if [ $? -eq 0 ]; then ## Verifica se a operação correu bem
    so_success S2.2.3
else
    so_error S2.2.3
    exit 9
fi
## S2.2.4. Regista a compra no ficheiro relatorio_reservas.txt, inserido uma nova linha no final deste ficheiro. Em caso de erro (por exemplo, na escrita do ficheiro), dá so_error e termina. Caso contrário, dá so_success.

touch relatorio_reservas.txt ## Cria o relatorio_reservas.txt
ID_reserva=$(($(tail -n 1 relatorio_reservas.txt | cut -d ':' -f 1) + 1)) ## Calcula o id da reserva
Origem=$(awk -F ':' -v origem_destino="$origem_destino" '$2 == origem_destino || $3 == origem_destino { if ($8 > 0) print $0 }' voos.txt | grep -n "$origem_destino" | sed -n "${opcao_voo}p" | cut -d ':' -f 3) ## Pega a origem do voo escolhido pelo user
Destino=$(awk -F ':' -v origem_destino="$origem_destino" '$2 == origem_destino || $3 == origem_destino { if ($8 > 0) print $0 }' voos.txt | grep -n "$origem_destino" | sed -n "${opcao_voo}p" | cut -d ':' -f 4) ## Pega o destino do voo escolhido pelo user
Data_reserva=$(date +"%Y-%m-%d") ## Pega a data no momento da reserva no formato pretendido
Hora_reserva=$(date +"%Hh%M") ## Pega a hora no momento da reserva no formato pretendido
reserva=$"$ID_reserva:$id_voo:$Origem:$Destino:$preco:$id:$Data_reserva:$Hora_reserva" ## Junta todas as informações numa variável que funcionará como uma "linha"
echo $reserva >> relatorio_reservas.txt ## Escreve essa linha no fim do relatorio_reservas.txt
if [ $? -eq 0 ]; then ## Verifica se a operação correu bem
    so_success S2.2.4
else
    so_error S2.2.4
    exit 9
fi

