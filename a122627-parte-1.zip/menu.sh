#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. ./so_utils.sh                     ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024, Enunciado Versão 3+
##
## Aluno: Nº:   a122627    Nome: Gonçalo Guilherme
## Nome do Módulo: S5. Script: menu.sh
## Descrição/Explicação do Módulo:
## O objetivo do módulo é criar um menu onde o user pode realizar todas as outras operações já realizadas anteriormente
## Neste módulo será usado um loop que sempre que a opção dada pelo user é diferente 0, ele faz a operação pretendida e volta ao menu inicial (o menu é mostrado logo após a invocação do script )
###############################################################################

## Este script invoca os scripts restantes, não recebendo argumentos. Atenção: Não é suposto que volte a fazer nenhuma das funcionalidades dos scripts anteriores. O propósito aqui é simplesmente termos uma forma centralizada de invocar os restantes scripts.

## S5.1. Apresentação:
## S5.1.1. O script apresenta (pode usar echo, cat ou outro, sem “limpar” o ecrã) um menu com as opções indicadas no enunciado (1 a 5, ou 0 para sair). 
## S5.2. Validações:
## S5.2.1. Aceita como input do utilizador um número. Valida que a opção introduzida corresponde a uma opção válida. Se não for, dá so_error 
## <opção> (com a opção errada escolhida), e volta ao passo S5.1 (ou seja, mostra novamente o menu). Caso contrário, dá so_success <opção>.
## S5.2.2. Analisa a opção escolhida, e mediante cada uma delas, deverá invocar o sub-script correspondente descrito nos pontos S1 a S4 acima. No caso das opções 1 e 4, este script deverá pedir interactivamente ao utilizador as informações necessárias para execução do sub-script correspondente, injetando as mesmas como argumentos desse sub-script:
## S5.2.2.1. Assim sendo, no caso da opção 1, o script deverá pedir ao utilizador sucessivamente e interactivamente os dados a inserir (Nome, Senha, NIF e Saldo a adicionar). Repare que, no exemplo dado no enunciado, não foi inserido qualquer NIF, portanto, indicando que não pretende registar o passageiro, mas sim apenas adicionar saldo ao mesmo, correspondendo esta introdução assim ao primeiro exemplo de invocação via argumentos indicada em S1, que se destina apenas a adicionar 500 euros ao saldo do passageiro já existente "Fábio Cardoso", validando essa adição de créditos pela inserção da senha do passageiro. Este script não deverá fazer qualquer validação dos dados inseridos, já que essa validação é feita no script S1. Após receber os dados, este script invoca o Sub-Script: regista_passageiro.sh com os argumentos recolhidos do utilizador. Após a execução do sub-script, dá so_success e volta ao passo S5.1.
## S5.2.2.2. No caso da opção 2, o script invoca o Sub-Script: compra_bilhete.sh. Após a execução do sub-script, dá so_success e volta para o passo S5.1.
## S5.2.2.3. No caso da opção 3, o script invoca o Sub-Script: estado_voos.sh. Após a execução do sub-script, dá so_success e volta para o passo S5.1.
## S5.2.2.4. No caso da opção 4, o script invoca o Sub-Script: stats.sh com o argumento necessário. Após a execução do sub-script, dá so_success e volta para o passo S5.1.
## S5.2.2.5. No caso da opção 5, o script deverá pedir ao utilizador o nº de voos a listar, antes de invocar o Sub-Script: stats.sh. Após a execução do sub-script, dá so_success e volta para o passo S5.1. Apenas a opção 0 (zero) permite sair deste Script: menu.sh. Até escolher esta opção, o menu deverá ficar em ciclo, permitindo realizar múltiplas operações iterativamente (e não recursivamente, ou seja, não deverá chamar o Script: menu.sh novamente). 

while [ "$opcao" != 0 ]; do ## Ciclo que repete o menu sempre que a opção seja diferente de 0 (depois de efetuar a operação desejada)
echo -n "MENU:
1: Regista/Atualiza saldo do passageiro
2: Reserva/Compra de bilhetes
3: Atualiza Estado dos voos
4: Estatísticas - Passageiros
5: Estatísticas - Top Voos + Rentáveis
0: Sair


Opção: " 
read -r opcao ## Permite que o user escreva a opção pretendida 
        
    if [[ "$opcao" -gt 5 ]] || [[ "$opcao" -lt 0 ]]; then ## Verifica se a opção é válida 
        so_error S5.2.1 "$opcao"
        continue ## Volta ao início do while 
    else
        so_success "$opcao"
    fi

    case $opcao in ## Switch case para cada opção possível (0 não é necessário uma vez que saíria do ciclo while)
        1)  ## Opção 1
            echo "Regista/Atualiza saldo do passageiro" ## Título da opção escolhida
            read -p "Indique o nome: " nome_passageiro ## O user escreve o nome a ser usado
            read -p "Indique a senha: " senha ## O user escreve a senha a ser usada
            read -p "Para registar o passageiro, insira o NIF: " NIF ## O user escreve o NIF a ser usado
            read -p "Indique o saldo a adicionar ao passageiro: " saldo_a_adicionar ## O user escreve o saldo a ser usado
            source regista_passageiro.sh "$nome_passageiro" "$senha" "$saldo_a_adicionar" "$NIF" ## Vai buscar o script 1 com os argumentos dados pelo user
            if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
                so_success S5.2.2.1
            fi
            ;;
        2)  ## Opção 2
            echo "Reserva/Compra de bilhetes" ## Título da opção escolhida
            source compra_bilhete.sh ## Vai buscar o script 2
            if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
                so_success S5.2.2.2
            fi
            ;;
        3)  ## Opção 3
            echo "Atualiza Estado dos voos" ## Título da opção escolhida
            source estado_voos.sh ## Vai buscar o script 3
            if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
                so_success S5.2.2.3
            fi
            ;;
        4)  ## Opção 4
            echo "Estatísticas - Passageiros" ## Título da opção escolhida
            source stats.sh "passageiros" ## Vai buscar o script 4
            if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
                so_success S5.2.2.4
            fi
            ;;
        5)  ## Opção 5
            echo "Estatísticas - Top Voos + Rentáveis" ## Título da opção escolhida
            read -p "Indique o número de voos a listar: " top_numero  ## O user escreve o número a ser usado
            source stats.sh top "$top_numero" ## Vai buscar o script 4 com o número dado pelo user
            if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
                so_success S5.2.2.5
            fi
            ;;
    esac

done
