#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. ./so_utils.sh                     ## This is required to activate the macros so_success, so_error, and so_debug

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2023/2024, Enunciado Versão 3+
##
## Aluno: Nº:   122627    Nome: Gonçalo Teixeira Guilherme
## Nome do Módulo: S3. Script: estado_voos.sh
## Descrição/Explicação do Módulo:
## Neste módulo o ficheiro voos.txt é avaliado, isto é, as suas informações são verificadas e é criada uma página HTML com as informações de cada voo
## A página HTML deverá ser atualizada a cada hora por um ficheiro cron.def
###############################################################################

## Este script não recebe nenhum argumento, e é responsável pelo relatório do estado dos voos que pertencem à plataforma IscteFlight.

## S3.1. Validações:
## S3.1.1. O script valida se o ficheiro voos.txt existe. Se não existir, dá so_error e termina. Senão, dá so_success.

if [ -f "voos.txt" ]; then ## Verifica se voos.txt existe
    so_success S3.1.1
else
    so_error S3.1.1
    exit 9
fi

## S3.1.2. O script valida se os formatos de todos os campos de cada linha do ficheiro voos.txt correspondem à especificação indicada em S2, nomeadamente se respeitam os formatos de data e de hora. Se alguma linha não respeitar, dá so_error <conteúdo da linha> e termina. Caso contrário, dá so_success.

while IFS= read linha; do ## Irá percorrer cada linha de voos.txt
    echo $linha
    id_voo=$( echo "$linha" | cut -d ':' -f 1 ) ## Confirma se id do voo existe nas linhas de voos.txt
    if [ -z "$id_voo" ]; then ## Verifica se os id's dos voos estão válidos
        so_error S3.1.2 "$linha"
        exit 9
    fi
    origem=$( echo "$linha" | cut -d ':' -f 2 ) ## Confirma se origem existe nas linhas de voos.txt
    if [ -z "$origem" ]; then ## Verifica se as origens estão válidas
        so_error S3.1.2 "$linha"
        exit 9
    fi
    destino=$( echo "$linha" | cut -d ':' -f 3 ) ## Confirma se destino existe nas linhas de voos.txt
    if [ -z "$destino" ]; then ## Verifica se os destinos estão válidos
        so_error S3.1.2 "$linha"
        exit 9
    fi
    data=$( echo "$linha" | cut -d ':' -f 4 ) ## Confirma se data existe nas linhas de voos.txt
    if [ -z "$data" ] || [[ ! $data =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then ## Verifica se as datas estão válidas
        so_error S3.1.2 "$linha"
        exit 9
    fi
    hora=$( echo "$linha" | cut -d ':' -f 5 ) ## Confirma se hora existe nas linhas de voos.txt
    if [ -z "$hora" ] || [[ ! $hora =~ ^[0-9]{2}h[0-9]{2}$ ]]; then ## Verifica se as horas estão válidas
        so_error S3.1.2 "$linha"
        exit 9
    fi
    preco_voo=$( echo "$linha" | cut -d ':' -f 6 ) ## Confirma se o preço dos voos existe nas linhas de voos.txt
    if [ -z "$preco_voo" ] || [[ ! $preco_voo =~ ^[0-9]+$ ]]; then ## Verifica se o preço dos voos estão válidos
        so_error S3.1.2 "$linha"
        exit 9
    fi
    lotacao=$( echo "$linha" | cut -d ':' -f 7 ) ## Confirma se a lotação existe nas linhas de voos.txt
    if [ -z "$lotacao" ] || [[ ! $lotacao =~ ^[0-9]+$ ]]; then ## Verifica se as lotações estão válidas
        so_error S3.1.2 "$linha"
        exit 9
    fi
    disponiveis=$( echo "$linha" | cut -d ':' -f 8 ) ## Confirma se os lugares disponíveis existe nas linhas de voos.txt
    if [ -z "$disponiveis" ] || [[ ! $disponiveis =~ ^[0-9]+$ ]]; then ## Verifica se os lugares disponíveis estão válidos
        so_error S3.1.2 "$linha"
        exit 9
    fi
done < voos.txt
so_success S3.1.2


## S3.2. Processamento do script:
## S3.2.1. O script cria uma página em formato HTML, chamada voos_disponiveis.html, onde lista os voos com lugares disponíveis, indicando nº, origem, destino, data, hora, lotação, nº de lugares disponíveis, e nº de lugares ocupados (para isso deve calcular a diferença dos anteriores). Em caso de erro (por exemplo, se não conseguir escrever no ficheiro), dá so_error e termina. Caso contrário, dá so_success.

if [ ! -f "voos_disponiveis.html" ]; then ## Verifica se voos_disponiveis.html existe, se não, cria-o
    touch voos_disponiveis.html
fi

echo "<html><head><meta charset=\"UTF-8\"><title>IscteFlight: Lista de Voos Disponíveis</title></head>
<body><h1>Lista atualizada em $(date +"%Y-%m-%d %H:%M:%S")</h1>" > voos_disponiveis.html ## Cabeçalho da página HTML
while IFS=: read -r NrVoo Origem Destino DataPartida HoraPartida Preco Lotacao LugaresDisponiveis; do ## Faz as informações para cada voo disponível, isto é, com lugares disponíveis, na página HTML
    LugaresOcupados=$((Lotacao - LugaresDisponiveis))
    if [ "$LugaresDisponiveis" -gt 0 ]; then
        echo "<h2>Voo: $NrVoo, De: $Origem Para: $Destino, Partida em $DataPartida $HoraPartida</h2>
        <ul>
        <li><b>Lotação:</b> $Lotacao Lugares</li>
        <li><b>Lugares Disponíveis:</b> $LugaresDisponiveis Lugares</li>
        <li><b>Lugares Ocupados:</b> $LugaresOcupados Lugares</li>
        </ul>" >> voos_disponiveis.html
    fi
done < voos.txt
if [ "$?" -eq 0 ]; then ## Verifica se a operação correu bem
    echo "</body></html>" >> voos_disponiveis.html ## Fim da página HTML
    so_success S3.2.1
else 
    ## Se houve um erro durante o loop, exibe uma mensagem de erro e sai com código de erro 5
    so_error S3.2.1
    exit 9
fi

## S3.3. Invocação do script estado_voos.sh:
## S3.3.1. Altere o ficheiro cron.def fornecido, por forma a configurar o seu sistema para que o script seja executado de hora em hora, diariamente. Nos comentários no início do ficheiro cron.def, explique a configuração realizada, e indique qual o comando que deveria utilizar para despoletar essa configuração. O ficheiro cron.def alterado deverá ser submetido para avaliação juntamente com os outros Shell scripts.

## Resolução no cron.def